package com.axo.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.widget.ImageView

/** "Axo" sunte hi screen ke dono kinaron par neon frame dikhata hai aur 5 second baad hata deta hai. */
object OverlayManager {
    private val handler = Handler(Looper.getMainLooper())
    private var view: ImageView? = null
    private var wm: WindowManager? = null
    private val hideRunnable = Runnable { hide() }

    fun show(ctx: Context, durationMs: Long = 5000) {
        val app = ctx.applicationContext
        if (!Settings.canDrawOverlays(app)) return
        handler.removeCallbacks(hideRunnable)
        if (view == null) {
            val manager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val iv = ImageView(app).apply {
                setImageResource(R.drawable.axo_frame)
                scaleType = ImageView.ScaleType.FIT_XY
                alpha = 0f
                scaleX = 1.06f
                scaleY = 1.06f
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            try {
                manager.addView(iv, lp)
            } catch (e: Exception) {
                return
            }
            wm = manager
            view = iv
        }
        view?.animate()?.cancel()
        view?.animate()?.alpha(1f)?.scaleX(1f)?.scaleY(1f)?.setDuration(300)?.start()
        handler.postDelayed(hideRunnable, durationMs)
    }

    fun hide() {
        val v = view ?: return
        handler.removeCallbacks(hideRunnable)
        v.animate().cancel()
        v.animate().alpha(0f).setDuration(350).withEndAction {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
                // already removed
            }
            if (view === v) view = null
        }.start()
    }
}
