package com.axo.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat

object ContactResolver {
    /** Number mein country code na ho (10 digit) to ye laga diya jata hai. India = 91. */
    const val DEFAULT_COUNTRY_CODE = "91"

    private val aliases = mapOf(
        "papa" to listOf("papa", "पापा", "dad", "daddy", "pappa", "papaji", "pitaji", "father", "abbu"),
        "dad" to listOf("papa", "पापा", "dad", "daddy", "pappa", "papaji"),
        "mummy" to listOf("mummy", "मम्मी", "mom", "maa", "मां", "mama", "mother", "ammi"),
        "mom" to listOf("mummy", "मम्मी", "mom", "maa", "मां", "mother"),
        "maa" to listOf("mummy", "मम्मी", "mom", "maa", "मां", "mother"),
        "bhai" to listOf("bhai", "bhaiya", "bro", "भाई"),
        "didi" to listOf("didi", "sister", "दीदी")
    )

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}]"), "")

    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    private fun score(contact: String, wants: List<String>): Int {
        var best = 0
        for (t in wants) {
            if (t.isEmpty()) continue
            val s = when {
                contact == t -> 100
                contact.startsWith(t) -> 90
                contact.contains(t) -> 80
                contact.length >= 3 && t.contains(contact) -> 70
                t.length >= 4 && lev(contact, t) <= 1 -> 60
                t.length >= 6 && lev(contact, t) <= 2 -> 50
                else -> 0
            }
            if (s > best) best = s
        }
        return best
    }

    /** Naam se phone number (digits only, country code ke saath) dhundta hai. Thoda galat bola ho tab bhi. */
    fun find(ctx: Context, name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return null
        val key = norm(name)
        val wants = (aliases[key] ?: listOf(key)).map { norm(it) }
        var bestScore = 0
        var bestNumber: String? = null
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = norm(c.getString(0) ?: continue)
                val s = score(n, wants)
                if (s > bestScore) {
                    bestScore = s
                    bestNumber = c.getString(1)
                }
            }
        }
        return if (bestScore >= 50) bestNumber?.let { normalize(it) } else null
    }

    private fun normalize(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        if (d.startsWith("0")) d = d.drop(1)
        if (d.length == 10) d = DEFAULT_COUNTRY_CODE + d
        return d
    }
}
