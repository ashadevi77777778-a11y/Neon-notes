package com.axo.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Axo ka "haath": WhatsApp mein Send dabana, Spotify mein pehla gaana aur
 * YouTube mein pehla video chalana. Naam purana hai, kaam ab teeno ka hai.
 */
class WhatsAppAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var tickerRunning = false
    private var chipBottom = -1
    private var stageSince = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        AutomationState.serviceAlive = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        AutomationState.serviceAlive = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (anyPending()) ensureTicker()
    }

    override fun onInterrupt() {}

    private fun anyPending() =
        AutomationState.pendingSend || AutomationState.spotifyStage != 0 || AutomationState.ytPending

    private val ticker = object : Runnable {
        override fun run() {
            try {
                process()
            } catch (e: Exception) {
                // ignore, agli baar phir koshish
            }
            if (anyPending()) handler.postDelayed(this, 500) else tickerRunning = false
        }
    }

    private fun ensureTicker() {
        if (tickerRunning) return
        tickerRunning = true
        handler.post(ticker)
    }

    private fun process() {
        val now = System.currentTimeMillis()
        if (AutomationState.pendingSend && now - AutomationState.pendingAt > 25_000) AutomationState.pendingSend = false
        if (AutomationState.spotifyStage != 0 && now - AutomationState.spotifyAt > 30_000) AutomationState.spotifyStage = 0
        if (AutomationState.ytPending && now - AutomationState.ytAt > 25_000) AutomationState.ytPending = false

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (AutomationState.pendingSend && pkg.startsWith("com.whatsapp")) whatsapp(root)
        if (AutomationState.spotifyStage != 0 && pkg == "com.spotify.music") spotify(root, now)
        if (AutomationState.ytPending && pkg == "com.google.android.youtube") youtube(root)
    }

    // ---------------- WhatsApp ----------------
    private fun whatsapp(root: AccessibilityNodeInfo) {
        val node = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull()
            ?: root.findAccessibilityNodeInfosByViewId("com.whatsapp.w4b:id/send").firstOrNull()
            ?: findByDescription(root)
        if (node != null && clickUp(node)) AutomationState.pendingSend = false
    }

    private fun findByDescription(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString()?.trim()
        if (d != null && (d.equals("Send", true) || d == "भेजें")) return n
        for (i in 0 until n.childCount) {
            findByDescription(n.getChild(i))?.let { return it }
        }
        return null
    }

    // ---------------- Spotify ----------------
    private fun spotify(root: AccessibilityNodeInfo, now: Long) {
        when (AutomationState.spotifyStage) {
            1 -> {
                var chip: AccessibilityNodeInfo? = null
                walk(root) { n ->
                    if (chip == null) {
                        val t = n.text?.toString()?.trim()
                        val d = n.contentDescription?.toString()?.trim()
                        if (t.equals("Songs", true) || d.equals("Songs", true)) chip = n
                    }
                }
                val c = chip
                if (c != null) {
                    val r = Rect()
                    c.getBoundsInScreen(r)
                    chipBottom = r.bottom
                    if (clickUp(c)) {
                        AutomationState.spotifyStage = 2
                        stageSince = now
                    }
                } else if (now - AutomationState.spotifyAt > 9_000) {
                    chipBottom = -1
                    AutomationState.spotifyStage = 2
                    stageSince = now
                }
            }
            2 -> {
                if (now - stageSince < 1_300) return
                val row = firstRow(root)
                if (row != null && clickUp(row)) {
                    AutomationState.spotifyStage = 0
                    chipBottom = -1
                    handler.postDelayed({ mediaPlay() }, 2_500)
                }
            }
        }
    }

    private val skipLabels = setOf(
        "all", "songs", "artists", "albums", "playlists", "podcasts & shows", "podcasts", "profiles",
        "genres & moods", "audiobooks", "back", "clear text", "search", "home", "your library", "premium", "create"
    )

    private fun firstRow(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val dm = resources.displayMetrics
        val minTop = maxOf(chipBottom, (dm.heightPixels * 0.14).toInt())
        var best: AccessibilityNodeInfo? = null
        var bestTop = Int.MAX_VALUE
        walk(root) { n ->
            if (n.isClickable && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                val label = (n.text?.toString() ?: n.contentDescription?.toString() ?: firstText(n))
                    ?.trim()?.lowercase()
                if (r.top >= minTop && r.height() > 48 * dm.density && r.width() > dm.widthPixels * 0.5 &&
                    !label.isNullOrEmpty() && label !in skipLabels && r.top < bestTop
                ) {
                    best = n
                    bestTop = r.top
                }
            }
        }
        return best
    }

    private fun firstText(n: AccessibilityNodeInfo?): String? {
        if (n == null) return null
        val t = n.text?.toString()
        if (!t.isNullOrBlank()) return t
        for (i in 0 until n.childCount) {
            firstText(n.getChild(i))?.let { return it }
        }
        return null
    }

    private fun mediaPlay() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
    }

    // ---------------- YouTube ----------------
    private fun youtube(root: AccessibilityNodeInfo) {
        var best: AccessibilityNodeInfo? = null
        var bestTop = Int.MAX_VALUE
        walk(root) { n ->
            val d = n.contentDescription?.toString()?.lowercase()
            if (d != null && d.contains("play video")) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.top < bestTop && r.height() > 0) {
                    best = n
                    bestTop = r.top
                }
            }
        }
        val b = best
        if (b != null && clickUp(b)) AutomationState.ytPending = false
    }

    // ---------------- helpers ----------------
    private fun walk(n: AccessibilityNodeInfo?, fn: (AccessibilityNodeInfo) -> Unit) {
        if (n == null) return
        fn(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), fn)
    }

    private fun clickUp(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }
}
