package com.axo.assistant.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.axo.assistant.Assistant
import com.axo.assistant.Kind
import com.axo.assistant.OverlayManager
import com.axo.assistant.Store
import com.axo.assistant.WhatsAppAccessibilityService
import kotlin.math.cos
import kotlin.math.sin

// ------------------------------------------------------------------ helpers

@Composable
fun T(
    s: String, size: Int = 14, w: FontWeight = FontWeight.Normal, c: Color = C.Text,
    align: TextAlign? = null, modifier: Modifier = Modifier
) = Text(s, color = c, fontSize = size.sp, fontWeight = w, textAlign = align, modifier = modifier)

fun Kind.icon(): ImageVector = when (this) {
    Kind.CHAT -> Icons.Filled.Chat
    Kind.MUSIC -> Icons.Filled.MusicNote
    Kind.VIDEO -> Icons.Filled.PlayCircle
    Kind.CALL -> Icons.Filled.Call
    Kind.SEARCH -> Icons.Filled.Search
    Kind.TIME -> Icons.Filled.AccessTime
    Kind.APP -> Icons.Filled.Apps
    Kind.TORCH -> Icons.Filled.FlashlightOn
    Kind.VOLUME -> Icons.Filled.VolumeUp
    Kind.ALARM -> Icons.Filled.Alarm
    Kind.UNKNOWN -> Icons.Filled.Star
}

data class Tile(val title: String, val sub: String, val icon: ImageVector, val color: Color, val cmd: String)

private val tiles = listOf(
    Tile("WhatsApp", "Message bhejo", Icons.Filled.Chat, Color(0xFFB45CFF), "whatsapp kholo"),
    Tile("Spotify", "Song play karo", Icons.Filled.MusicNote, Color(0xFFFF2D55), "spotify se english song play kardo"),
    Tile("YouTube", "Video chalao", Icons.Filled.PlayCircle, Color(0xFF3B6BFF), "youtube par lofi chalao"),
    Tile("Call", "Dialer kholo", Icons.Filled.Call, Color(0xFF8A2BFF), "phone kholo"),
    Tile("Web Search", "Google par dhundo", Icons.Filled.Search, Color(0xFF2F9FFF), "search karo latest news"),
    Tile("Torch", "On karo", Icons.Filled.FlashlightOn, Color(0xFFFFB429), "torch on karo")
)

private val examples = listOf(
    "Axo, Spotify se ek english song play kardo" to Kind.MUSIC,
    "Axo, WhatsApp kholo aur message karo Papa ko Hello" to Kind.CHAT,
    "Axo, Mummy ko call karo" to Kind.CALL,
    "Axo, YouTube par lofi chalao" to Kind.VIDEO,
    "Axo, search karo best phones 2026" to Kind.SEARCH,
    "Axo, torch on karo / torch band karo" to Kind.TORCH,
    "Axo, volume badhao / kam karo / full karo" to Kind.VOLUME,
    "Axo, alarm laga do 6:30 am" to Kind.ALARM,
    "Axo, WhatsApp kholo aur Papa ko Hello bhejo aur fir Spotify par english song play karo" to Kind.CHAT,
    "Axo, Instagram kholo" to Kind.APP,
    "Axo, abhi kitne baje hain" to Kind.TIME
)

// ------------------------------------------------------------------ root

@Composable
fun AxoApp(onToggle: () -> Unit, onGrantAll: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(containerColor = C.Bg, bottomBar = { BottomBar(tab) { tab = it } }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(onToggle) { tab = it }
                1 -> ListScreen("Explore commands", examples.map { Triple(it.first, "Bolkar try karo", it.second) })
                2 -> HistoryScreen()
                else -> ProfileScreen(onGrantAll)
            }
        }
    }
}

@Composable
private fun ListScreen(title: String, rows: List<Triple<String, String, Kind>>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        T(title, 22, FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
        Column(Modifier.clip(RoundedCornerShape(18.dp)).background(C.Card)) {
            rows.forEach { (a, b, k) -> CmdRow(k, a, b, null) }
        }
    }
}

@Composable
private fun HistoryScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        T("History", 22, FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
        if (Store.history.isEmpty()) T("Abhi koi command nahi.", 14, c = C.Muted)
        else Column(Modifier.clip(RoundedCornerShape(18.dp)).background(C.Card)) {
            Store.history.forEach { h -> CmdRow(h.kind, h.command, h.reply) { Assistant.execute(ctx, h.command) } }
        }
    }
}

@Composable
private fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val items = listOf("Home" to Icons.Filled.Home, "Explore" to Icons.Filled.Explore,
        "History" to Icons.Filled.History, "Profile" to Icons.Filled.Person)
    NavigationBar(containerColor = Color(0xFF0A0514)) {
        items.forEachIndexed { i, (label, icon) ->
            NavigationBarItem(
                selected = sel == i, onClick = { onSel(i) },
                icon = { Icon(icon, label) }, label = { Text(label, fontSize = 12.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = C.PurpleL, selectedTextColor = C.PurpleL,
                    indicatorColor = Color(0xFF1A0F30),
                    unselectedIconColor = C.Muted, unselectedTextColor = C.Muted
                )
            )
        }
    }
}

// ------------------------------------------------------------------ home

@Composable
private fun HomeScreen(onToggle: () -> Unit, go: (Int) -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    val send = {
        if (text.isNotBlank()) {
            Assistant.execute(ctx, text); text = ""
        }
    }
    Column(
        Modifier.fillMaxSize()
            .drawBehind {
                drawRect(Brush.radialGradient(listOf(C.Purple.copy(alpha = .35f), Color.Transparent),
                    center = Offset(0f, size.height * .22f), radius = size.width * 1.0f))
                drawRect(Brush.radialGradient(listOf(C.Crimson.copy(alpha = .30f), Color.Transparent),
                    center = Offset(size.width, size.height * .25f), radius = size.width * 1.0f))
            }
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Header(go)
        Hero(Store.listening)
        Text(
            buildAnnotatedString {
                append("Hello, ")
                withStyle(SpanStyle(brush = Grad)) { append("Explorer!") }
                append(" 👋")
            },
            color = C.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
        T(Store.status, 15, c = C.Muted, align = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).heightIn(min = 44.dp))

        Spacer(Modifier.height(14.dp))
        AskBar(text, { text = it }, send, onToggle)

        Spacer(Modifier.height(16.dp))
        tiles.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t -> TileCard(t, Modifier.weight(1f)) { Assistant.execute(ctx, t.cmd) } }
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            T("Recent Commands", 18, FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("See All", color = C.PurpleL, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable { go(2) })
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Card)) {
            if (Store.history.isEmpty()) {
                examples.take(3).forEach { (cmd, k) ->
                    CmdRow(k, cmd.removePrefix("Axo, "), "Try karo") { Assistant.execute(ctx, cmd) }
                }
            } else {
                Store.history.take(3).forEach { h ->
                    CmdRow(h.kind, h.command, h.reply) { Assistant.execute(ctx, h.command) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Header(go: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Logo(Modifier.size(44.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = C.Text)) { append("Axo ") }
                    withStyle(SpanStyle(color = C.PurpleL)) { append("Assistant") }
                },
                fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
            T("Your Smart AI Assistant", 13, c = C.Muted)
        }
        RoundIcon(Icons.Filled.WorkspacePremium, Color(0xFFFFB429)) {}
        Spacer(Modifier.width(8.dp))
        RoundIcon(Icons.Filled.Settings, Color.White) { go(3) }
    }
}

@Composable
private fun RoundIcon(icon: ImageVector, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF120A24))
            .border(1.dp, C.Line, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
}

@Composable
private fun Logo(m: Modifier) = Canvas(m) {
    val w = size.width
    val p = Path().apply {
        moveTo(w * .5f, w * .08f); lineTo(w * .12f, w * .9f); lineTo(w * .28f, w * .9f)
        lineTo(w * .5f, w * .42f); lineTo(w * .72f, w * .9f); lineTo(w * .88f, w * .9f); close()
    }
    drawPath(p, Grad)
    rotate(-18f) {
        drawOval(C.PurpleL, topLeft = Offset(0f, w * .52f), size = Size(w, w * .3f), style = Stroke(2.dp.toPx()))
    }
}

@Composable
private fun Hero(listening: Boolean) {
    val inf = rememberInfiniteTransition(label = "hero")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "p")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "s")
    Canvas(Modifier.fillMaxWidth().height(250.dp)) {
        val c = center
        val r = size.height * .34f
        drawCircle(
            Brush.radialGradient(listOf(C.Purple.copy(alpha = .35f), Color.Transparent), center = c, radius = r * 2.2f),
            radius = r * 2.2f, center = c
        )
        if (listening) {
            drawCircle(C.Crimson.copy(alpha = 1f - pulse), radius = r * (1f + pulse * .5f), center = c,
                style = Stroke(3.dp.toPx()))
        }
        drawCircle(Color(0xFF12081F), radius = r, center = c)
        drawCircle(
            Brush.sweepGradient(listOf(C.Purple, C.PurpleL, C.Crimson, C.Purple), center = c),
            radius = r, center = c, style = Stroke(6.dp.toPx())
        )
        // orbit
        val rx = r * 1.7f
        val ry = r * .38f
        rotate(-14f, pivot = c) {
            drawOval(Grad, topLeft = Offset(c.x - rx, c.y - ry), size = Size(rx * 2, ry * 2), style = Stroke(2.dp.toPx()))
        }
        val a = Math.toRadians(spin.toDouble())
        val ex = rx * cos(a)
        val ey = ry * sin(a)
        val rot = Math.toRadians(-14.0)
        val px = c.x + ex * cos(rot) - ey * sin(rot)
        val py = c.y + ex * sin(rot) + ey * cos(rot)
        drawCircle(C.Crimson, 5.dp.toPx(), Offset(px.toFloat(), py.toFloat()))
        // letter A
        val br = Brush.linearGradient(listOf(C.Purple, C.Crimson),
            start = Offset(c.x - r * .5f, c.y), end = Offset(c.x + r * .5f, c.y))
        val sw = 10.dp.toPx()
        val top = Offset(c.x, c.y - r * .55f)
        drawLine(br, top, Offset(c.x - r * .45f, c.y + r * .5f), sw, StrokeCap.Round)
        drawLine(br, top, Offset(c.x + r * .45f, c.y + r * .5f), sw, StrokeCap.Round)
        drawLine(br, Offset(c.x - r * .22f, c.y + r * .2f), Offset(c.x + r * .22f, c.y + r * .2f), sw, StrokeCap.Round)
    }
}

@Composable
private fun AskBar(value: String, onChange: (String) -> Unit, onSend: () -> Unit, onMic: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(CircleShape).background(Color(0xFF0B0618))
            .border(1.5.dp, Grad, CircleShape).padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = C.Text, fontSize = 16.sp),
            cursorBrush = SolidColor(C.PurpleL),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                if (value.isEmpty()) Text("Ask anything...", color = C.Muted, fontSize = 16.sp)
                inner()
            }
        )
        Box(
            Modifier.size(46.dp).clip(CircleShape)
                .background(if (Store.listening) Brush.linearGradient(listOf(C.Crimson, C.Purple)) else SolidColor(Color(0xFF1A0F30)))
                .clickable(onClick = onMic),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Mic, "Mic", tint = Color.White, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(46.dp).clip(CircleShape)
                .background(Brush.linearGradient(listOf(C.Crimson, C.Purple))).clickable(onClick = onSend),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = Color.White, modifier = Modifier.size(20.dp)) }
    }
}

@Composable
private fun TileCard(t: Tile, m: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        m.height(100.dp).clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1A0B34), Color(0xFF12081F))))
            .border(1.dp, t.color.copy(alpha = .8f), shape)
            .clickable(onClick = onClick).padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(t.icon, null, tint = t.color, modifier = Modifier.size(26.dp))
        Column {
            T(t.title, 14, FontWeight.SemiBold)
            T(t.sub, 11, c = C.Muted)
        }
    }
}

@Composable
private fun CmdRow(kind: Kind, title: String, sub: String, onClick: (() -> Unit)?) {
    val base = Modifier.fillMaxWidth()
    Row(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                .background(if (kind == Kind.MUSIC) Color(0xFF2A0B19) else Color(0xFF1C0F38)),
            contentAlignment = Alignment.Center
        ) {
            Icon(kind.icon(), null, tint = if (kind == Kind.MUSIC) C.Crimson else C.PurpleL, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            T(title, 15, FontWeight.SemiBold)
            T(sub, 12, c = C.Muted)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = C.Muted)
    }
}

// ------------------------------------------------------------------ profile / setup

private data class Setup(val title: String, val desc: String, val ok: Boolean, val action: () -> Unit)

@Composable
private fun ProfileScreen(onGrantAll: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val rows = remember(tick) {
        fun perm(p: String) = ContextCompat.checkSelfPermission(ctx, p) == android.content.pm.PackageManager.PERMISSION_GRANTED
        fun open(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val acc = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(WhatsAppAccessibilityService::class.java.name) == true
        listOf(
            Setup("Microphone", "Axo ko sunne ke liye", perm(android.Manifest.permission.RECORD_AUDIO), onGrantAll),
            Setup("Contacts", "Papa, Mummy jaise naam match karne ke liye", perm(android.Manifest.permission.READ_CONTACTS), onGrantAll),
            Setup("Phone calls", "Seedha call lagane ke liye", perm(android.Manifest.permission.CALL_PHONE), onGrantAll),
            Setup("Display over other apps", "Background se Spotify/WhatsApp kholne ke liye",
                Settings.canDrawOverlays(ctx)) {
                open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            },
            Setup("Accessibility service", "WhatsApp mein Send apne aap dabane ke liye", acc) {
                open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            Setup("Battery unrestricted", "Axo ko background mein zinda rakhne ke liye",
                pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
                open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        )
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        T("Setup & Profile", 22, FontWeight.Bold)
        T("Sab green hone par Axo poori power se kaam karega.", 14, c = C.Muted, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        Column(Modifier.clip(RoundedCornerShape(18.dp)).background(C.Card)) {
            rows.forEach { r ->
                Row(Modifier.fillMaxWidth().clickable { r.action() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(r.title, 15, FontWeight.SemiBold)
                        T(r.desc, 12, c = C.Muted)
                    }
                    if (r.ok) Icon(Icons.Filled.Check, "OK", tint = Color(0xFF3DDC84))
                    else Text("Allow", color = C.Crimson, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        T("Note: Android 13+ par sideload app ke liye Accessibility pehle grey ho sakta hai. " +
            "App info > teen dot (⋮) > Allow restricted settings dabao, phir Accessibility on karo.",
            12, c = C.Muted, modifier = Modifier.padding(top = 14.dp))
        Box(
            Modifier.padding(top = 16.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
                .background(Grad).clickable { OverlayManager.show(ctx, 5000) }.padding(14.dp),
            contentAlignment = Alignment.Center
        ) { T("Wake effect test karo", 15, FontWeight.SemiBold) }
    }
}
