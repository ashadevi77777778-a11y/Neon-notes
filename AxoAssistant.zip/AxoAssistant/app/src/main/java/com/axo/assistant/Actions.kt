package com.axo.assistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Actions {
    private const val SPOTIFY = "com.spotify.music"
    private const val WHATSAPP = "com.whatsapp"
    private var torchOn = false

    fun run(ctx: Context, c: Command): String = try {
        exec(ctx, c)
    } catch (e: Exception) {
        "Ye kaam nahi ho paya: ${e.message ?: "unknown error"}"
    }

    private fun exec(ctx: Context, c: Command): String = when (c) {
        is Command.Spotify -> spotify(ctx, c.query)
        is Command.WhatsApp -> whatsapp(ctx, c)
        is Command.YouTube -> youtube(ctx, c.query)
        is Command.Call -> call(ctx, c.name)
        is Command.Search -> {
            start(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, c.query))
            "Google par ${c.query} dhundh raha hu."
        }
        is Command.OpenApp -> openApp(ctx, c.name)
        is Command.Torch -> torch(ctx, c.on)
        is Command.Volume -> volume(ctx, c.mode)
        is Command.Alarm -> alarm(ctx, c.hour, c.minute)
        Command.Time -> "Abhi samay hai " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        is Command.Unknown -> "Ye command samajh nahi aaya. Dobara bolo."
    }

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    // ---------- Spotify: pehla song seedha play ----------
    private fun spotify(ctx: Context, query: String): String {
        if (AutomationState.serviceAlive) {
            // Search khol kar accessibility service pehla gaana apne aap dabayegi
            AutomationState.spotifyAt = System.currentTimeMillis()
            AutomationState.spotifyStage = 1
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(query))).setPackage(SPOTIFY)
            return try {
                start(ctx, i)
                "Spotify par $query ka pehla gaana chala raha hu."
            } catch (e: Exception) {
                AutomationState.spotifyStage = 0
                browser(ctx, "https://open.spotify.com/search/" + Uri.encode(query), "Spotify app nahi mila, browser mein $query khol diya.")
            }
        }
        // Accessibility band hai: purana tareeka
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(SPOTIFY)
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        }
        return try {
            start(ctx, i)
            Handler(Looper.getMainLooper()).postDelayed({ mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY) }, 3000)
            "Spotify par $query khol raha hu. Pehla gaana apne aap chalane ke liye Accessibility on karo."
        } catch (e: Exception) {
            browser(ctx, "https://open.spotify.com/search/" + Uri.encode(query), "Spotify app nahi mila, browser mein $query khol diya.")
        }
    }

    private fun browser(ctx: Context, url: String, reply: String): String {
        start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        return reply
    }

    private fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // ---------- WhatsApp: message khol kar auto-send ----------
    private fun whatsapp(ctx: Context, c: Command.WhatsApp): String {
        val number = ContactResolver.find(ctx, c.name)
            ?: return "${c.name} naam ka contact nahi mila. Contacts permission aur naam check karo."
        val uri = Uri.parse("https://wa.me/$number?text=" + Uri.encode(c.message))
        val alive = AutomationState.serviceAlive
        if (alive) {
            AutomationState.pendingAt = System.currentTimeMillis()
            AutomationState.pendingSend = true
        }
        start(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(WHATSAPP))
        return if (alive) "${c.name} ko ${c.message} bhej raha hu."
        else "${c.name} ka chat khol diya. Accessibility on nahi hai, Send aap dabao."
    }

    private fun youtube(ctx: Context, q: String): String {
        if (q.isEmpty()) return openApp(ctx, "youtube")
        if (AutomationState.serviceAlive) {
            AutomationState.ytAt = System.currentTimeMillis()
            AutomationState.ytPending = true
        }
        val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube")
            .putExtra(SearchManager.QUERY, q)
        return try {
            start(ctx, i)
            "YouTube par $q chala raha hu."
        } catch (e: Exception) {
            AutomationState.ytPending = false
            browser(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(q), "Browser mein YouTube par $q khol diya.")
        }
    }

    private fun call(ctx: Context, name: String): String {
        val number = ContactResolver.find(ctx, name)
            ?: return "$name ka number contacts mein nahi mila."
        val uri = Uri.parse("tel:+$number")
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        start(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return "$name ko call laga raha hu."
    }

    private fun openApp(ctx: Context, name: String): String {
        if (name in listOf("dialer", "phone", "call")) {
            start(ctx, Intent(Intent.ACTION_DIAL)); return "Dialer khol raha hu."
        }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name.lowercase())
        } ?: return "$name naam ka app nahi mila."
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "$name khul nahi paya."
        start(ctx, i)
        return "${match.loadLabel(pm)} khol raha hu."
    }

    private fun torch(ctx: Context, on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Is phone mein torch nahi mili."
        cm.setTorchMode(id, on)
        torchOn = on
        return if (on) "Torch on kar di." else "Torch band kar di."
    }

    private fun volume(ctx: Context, mode: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = (max / 5).coerceAtLeast(1)
        val target = when (mode) {
            "MAX" -> max
            "UP" -> (cur + step).coerceAtMost(max)
            "DOWN" -> (cur - step).coerceAtLeast(0)
            else -> 0
        }
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return when (mode) {
            "MAX" -> "Volume full kar diya."
            "UP" -> "Volume badha diya."
            "DOWN" -> "Volume kam kar diya."
            else -> "Volume mute kar diya."
        }
    }

    private fun alarm(ctx: Context, h: Int, m: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(ctx, i)
        return "Alarm set kar diya: %02d:%02d.".format(h, m)
    }
}
