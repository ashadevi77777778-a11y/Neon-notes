package com.axo.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object C {
    val Bg = Color(0xFF05030B)
    val Card = Color(0xFF0F0820)
    val Line = Color(0xFF2A1650)
    val Crimson = Color(0xFFFF2D55)
    val Purple = Color(0xFF8A2BFF)
    val PurpleL = Color(0xFFB45CFF)
    val Muted = Color(0xFFA597BD)
    val Text = Color(0xFFF5EFFF)
}

val Grad = Brush.horizontalGradient(listOf(C.Purple, C.Crimson))

@Composable
fun AxoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Purple,
            background = C.Bg,
            surface = C.Card,
            onSurface = C.Text,
            onBackground = C.Text
        ),
        content = content
    )
}
