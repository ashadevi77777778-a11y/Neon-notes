package com.axo.assistant

import java.util.Locale

/** Hinglish / English voice text ko Command (ya commands ki list) mein badalta hai. */
object CommandProcessor {
    private const val W = "[\\p{L}\\p{M}]+"
    private const val WAKE_WORDS =
        "axo|akso|aksho|aksa|exo|ekso|ekxo|aexo|acxo|axxo|acso|accso|aixo|hexo|axe o|ax o|ak so|ex o"
    private val WAKE = Regex("\\b($WAKE_WORDS)\\b|एक्सो|अक्सो|एक्सओ", RegexOption.IGNORE_CASE)

    private const val KW =
        "whatsapp|whats app|spotify|youtube|call|dial|torch|flashlight|flash|volume|alarm|search|google|" +
            "kholo|khol|open|play|bajao|chalao|message|msg|song|songs|gaana|gana|ganna|music|sunao"
    private val SPLIT = Regex(
        "\\s+(?:aur fir|aur phir|aur uske baad|uske baad|aur|phir|fir|then|and then|and|also)\\s+(?=.*\\b(?:$KW)\\b)"
    )

    /** Wake word ke baad ka index (na mile to null). */
    fun wakeEnd(text: String): Int? = WAKE.find(text)?.let { it.range.last + 1 }

    private fun has(t: String, pattern: String) = Regex(pattern).containsMatchIn(t)
    private fun strip(t: String, words: String) =
        t.replace(Regex("\\b($words)\\b"), " ").replace(Regex("\\s+"), " ").trim()

    private fun clean(raw: String): String {
        val t = WAKE.replace(raw.lowercase(Locale.ROOT), " ")
        return t.replace(Regex("[,.!?।]"), " ").replace(Regex("\\s+"), " ").trim()
    }

    /** Lamba command (aur / phir / uske baad) ko alag alag kaamon mein todta hai. */
    fun parseChain(raw: String): List<Command> {
        val t = clean(raw)
        val parts = t.split(SPLIT).map { it.trim() }.filter { it.isNotEmpty() }
        val cmds = mutableListOf<Command>()
        for (p in parts) {
            val prev = cmds.lastOrNull()
            val afterWa = prev is Command.OpenApp && prev.name.contains("whats")
            val m = Regex("^($W)\\s+(?:ko|को)\\s+(.+)$").find(p)
            if (afterWa && m != null && !has(p, "\\b(call|dial|spotify|youtube|play|song|songs)\\b")) {
                cmds.add(Command.WhatsApp(m.groupValues[1], cleanMsg(m.groupValues[2])))
            } else {
                cmds.add(parse(p))
            }
        }
        val out = mutableListOf<Command>()
        for ((i, c) in cmds.withIndex()) {
            val next = cmds.getOrNull(i + 1)
            if (c is Command.OpenApp && next != null) {
                val n = c.name
                val redundant = (next is Command.WhatsApp && n.contains("whats")) ||
                    (next is Command.Spotify && n.contains("spotify")) ||
                    (next is Command.YouTube && n.contains("youtube"))
                if (redundant) continue
            }
            if (c is Command.Unknown && cmds.size > 1) continue
            out.add(c)
        }
        return if (out.isEmpty()) listOf(Command.Unknown(raw)) else out
    }

    fun parse(raw: String): Command {
        var t = clean(raw)
        if (t.isEmpty()) return Command.Unknown(raw)
        // "ganna / gana / gaana" ko "song" bana do, taaki Spotify search sahi ho
        t = t.replace(Regex("\\b(ganna|ganne|gana|gaana|gaane|gane|gaano)\\b|गाना|गाने"), "song")

        if (has(t, "torch|flashlight|flash light|flash|tarch|टॉर्च"))
            return Command.Torch(!has(t, "\\boff\\b|band|bund|bandh|बंद"))

        if (has(t, "volume|awaz|awaaz|आवाज")) {
            val mode = when {
                has(t, "full|max") -> "MAX"
                has(t, "badha|up|increase|zyada|tez|high") -> "UP"
                has(t, "kam|ghata|down|decrease|low|dheere") -> "DOWN"
                has(t, "mute|band|silent") -> "MUTE"
                else -> "UP"
            }
            return Command.Volume(mode)
        }

        if (has(t, "kitne baje|time kya|what time|samay|abhi time|time batao|टाइम"))
            return Command.Time

        if (has(t, "alarm")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm)?").find(t)
                ?: return Command.Unknown(raw)
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            return Command.Alarm(h % 24, min % 60)
        }

        // WhatsApp / message
        val isWa = has(t, "whats\\s?app|व्हाट्सएप|वाट्सएप|व्हाट्सऐप") || has(t, "\\b(message|msg|massage|sms)\\b")
        if (isWa) {
            val a = Regex("($W)\\s+(?:ko|को)\\s+(.+)$").find(t)
            val b = Regex("(?:send|message|msg)\\s+(.+?)\\s+to\\s+($W)").find(t)
            return when {
                a != null -> Command.WhatsApp(a.groupValues[1], cleanMsg(a.groupValues[2]))
                b != null -> Command.WhatsApp(b.groupValues[2], cleanMsg(b.groupValues[1]))
                else -> Command.OpenApp("whatsapp")
            }
        }

        if (has(t, "\\b(call|dial)\\b|कॉल")) {
            val name = strip(t, "call|dial|karo|kardo|kar do|ko|lagao|laga do|laga|to|please")
            return if (name.isEmpty()) Command.Unknown(raw) else Command.Call(name)
        }

        if (has(t, "youtube|यूट्यूब")) {
            val q = strip(t, "youtube|par|pe|se|on|kholo|search|karo|kardo|play|chalao|dikhao|lagao|mein|me|ma|ek|ka|ki|ko")
            return Command.YouTube(q)
        }

        val playWords = has(t, "\\b(play|bajao|chalao|sunao|suna do|song|songs|music)\\b")
        if (has(t, "spotify") || playWords) {
            if (!playWords) return Command.OpenApp("spotify")
            val q = strip(
                t,
                "spotify|se|mein|me|ma|par|pe|on|background|play|kar do|kardo|karo|chalao|bajao|sunao|suna do|" +
                    "ek|ka|ki|ko|a|the|please|bhi|laga do|laga de|laga dena|lagao|mere liye|mujhe|koi|kuch|accha|acha|wala|wale|wali"
            )
            return Command.Spotify(if (q.isEmpty() || q == "song" || q == "songs") "top hits" else q)
        }

        if (has(t, "\\b(kholo|khol do|khol|open|launch)\\b")) {
            val name = strip(t, "kholo|khol do|khol|open|launch|app|ko|karo|kardo|please|chalu|on")
            if (name.isNotEmpty()) return Command.OpenApp(name)
        }

        if (has(t, "\\b(search|google|dhundo|khojo)\\b")) {
            val q = strip(t, "search|google|dhundo|khojo|karo|kardo|par|pe|se|mein|me|ma|batao|for|about")
            if (q.isNotEmpty()) return Command.Search(q)
        }
        return Command.Unknown(raw)
    }

    private fun cleanMsg(m: String): String {
        var s = m.trim()
        s = s.replace(Regex("^(message|msg|massage|sms)\\s*(karo|kardo|kar do|bhejo|bhej do|likho|likh do)?\\s*"), "")
        s = s.replace(Regex("^(ki|ye|yeh)\\s+"), "")
        s = s.replace(Regex("\\s+(message|msg|massage)\\s*(karo|bhejo|kardo|kar do|bhej do)?$"), "")
        s = s.replace(Regex("\\s+(bhejo|bhej do|bol do|bolo|likh do|likho)$"), "")
        s = s.trim().ifEmpty { m.trim() }
        return s.replaceFirstChar { it.uppercase() }
    }
}
