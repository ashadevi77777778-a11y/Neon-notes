package com.axo.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

enum class Kind { CHAT, MUSIC, VIDEO, CALL, SEARCH, TIME, APP, TORCH, VOLUME, ALARM, UNKNOWN }

sealed class Command(val kind: Kind) {
    data class WhatsApp(val name: String, val message: String) : Command(Kind.CHAT)
    data class Spotify(val query: String) : Command(Kind.MUSIC)
    data class YouTube(val query: String) : Command(Kind.VIDEO)
    data class Call(val name: String) : Command(Kind.CALL)
    data class Search(val query: String) : Command(Kind.SEARCH)
    data class OpenApp(val name: String) : Command(Kind.APP)
    data class Torch(val on: Boolean) : Command(Kind.TORCH)
    data class Volume(val mode: String) : Command(Kind.VOLUME)
    data class Alarm(val hour: Int, val minute: Int) : Command(Kind.ALARM)
    object Time : Command(Kind.TIME)
    data class Unknown(val text: String) : Command(Kind.UNKNOWN)
}

data class HistoryItem(val command: String, val reply: String, val kind: Kind)

/** UI ke liye shared state. */
object Store {
    var listening by mutableStateOf(false)
    var status by mutableStateOf("Axo soya hua hai. Mic dabao aur bolo: Axo...")
    val history = mutableStateListOf<HistoryItem>()

    fun add(item: HistoryItem) {
        history.add(0, item)
        while (history.size > 50) history.removeAt(history.lastIndex)
    }
}

/** Accessibility service ke liye pending kaam. */
object AutomationState {
    @Volatile var serviceAlive = false
    @Volatile var pendingSend = false
    @Volatile var pendingAt = 0L
    @Volatile var spotifyStage = 0      // 0 = kuch nahi, 1 = Songs chip dhundo, 2 = pehla gaana dabao
    @Volatile var spotifyAt = 0L
    @Volatile var ytPending = false
    @Volatile var ytAt = 0L
}

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    @Volatile var speaking = false

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                tts?.language = Locale("en", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking = true }
                    override fun onDone(utteranceId: String?) { speaking = false }
                    override fun onError(utteranceId: String?) { speaking = false }
                })
            }
        }
    }

    fun speak(text: String) {
        if (!ready) return
        speaking = true
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "axo")
        if (r != TextToSpeech.SUCCESS) speaking = false
    }
}

object Assistant {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    /** Ek ya kai kaam (aur, phir, uske baad...) ek ke baad ek chalata hai. */
    fun execute(ctx: Context, raw: String) {
        val app = ctx.applicationContext
        job?.cancel()
        job = scope.launch {
            val cmds = CommandProcessor.parseChain(raw)
            val replies = mutableListOf<String>()
            cmds.forEachIndexed { i, cmd ->
                val reply = Actions.run(app, cmd)
                replies.add(reply)
                Store.add(HistoryItem(if (cmds.size == 1) raw.trim() else describe(cmd), reply, cmd.kind))
                Store.status = reply
                if (i < cmds.lastIndex) waitFor(cmd)
            }
            val spoken = if (replies.size == 1) replies[0] else replies.joinToString(" ")
            Speaker.speak(spoken.trimEnd('.', ' ') + " sir")
        }
    }

    private suspend fun waitFor(cmd: Command) {
        when (cmd) {
            is Command.WhatsApp -> {
                waitUntil(22000) { !AutomationState.pendingSend || !AutomationState.serviceAlive }
                delay(1500)
            }
            is Command.Spotify -> {
                waitUntil(32000) { AutomationState.spotifyStage == 0 || !AutomationState.serviceAlive }
                delay(1500)
            }
            is Command.YouTube -> {
                waitUntil(27000) { !AutomationState.ytPending || !AutomationState.serviceAlive }
                delay(1500)
            }
            is Command.OpenApp, is Command.Search -> delay(2200)
            is Command.Call -> delay(3000)
            else -> delay(600)
        }
    }

    private suspend fun waitUntil(maxMs: Long, cond: () -> Boolean) {
        var t = 0L
        while (t < maxMs && !cond()) {
            delay(300)
            t += 300
        }
    }

    private fun describe(c: Command): String = when (c) {
        is Command.WhatsApp -> "WhatsApp: ${c.name} ko ${c.message}"
        is Command.Spotify -> "Spotify: ${c.query}"
        is Command.YouTube -> "YouTube: ${c.query}"
        is Command.Call -> "Call: ${c.name}"
        is Command.Search -> "Search: ${c.query}"
        is Command.OpenApp -> "Open: ${c.name}"
        is Command.Torch -> if (c.on) "Torch on" else "Torch off"
        is Command.Volume -> "Volume ${c.mode.lowercase()}"
        is Command.Alarm -> "Alarm %02d:%02d".format(c.hour, c.minute)
        Command.Time -> "Time"
        is Command.Unknown -> c.text
    }
}
