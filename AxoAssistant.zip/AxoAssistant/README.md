# Axo Assistant v1.1

Naya kya hai:
- Spotify: search khol kar pehla gaana apne aap chalta hai (Accessibility ke saath)
- YouTube: pehla video apne aap chalta hai
- "Axo" bolte hi screen ke dono kinaron par neon frame aata hai aur 5 second baad chala jata hai
- "Yes sir" bolkar jawab deta hai, ek kaam ke baad wapas so jata hai (dobara "Axo" bolna padega)
- Lambe commands: "Axo, WhatsApp kholo aur Papa ko Hello bhejo aur fir Spotify par english song play karo"
- Contacts mein naam thoda galat ho tab bhi dhundh leta hai (Papa, Pappa, Papa ji, Dad...)
- Fixed signing key: ab update install karne par purana app uninstall nahi karna padega (sirf is version ke baad)

Pehli baar (purane version ke upar): purana Axo uninstall karo, phir ye install karo.
Zip ka naam `AxoAssistant.zip` hi rakhna (GitHub workflow isi ko build karta hai).
